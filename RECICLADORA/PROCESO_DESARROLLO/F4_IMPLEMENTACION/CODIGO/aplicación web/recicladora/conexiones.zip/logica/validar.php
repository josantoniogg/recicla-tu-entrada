<?php
$recibeUsuario=$_POST['miUsuario'];
&recibeClave=$_POST['miClave'];

?>