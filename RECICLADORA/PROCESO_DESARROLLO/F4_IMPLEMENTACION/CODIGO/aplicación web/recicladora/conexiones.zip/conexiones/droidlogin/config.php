<?php
/**
 * Database config variables
 */
define("DB_HOST", "localhost");
define("DB_USER", "proyec34");//cambiar por el nombre de usuario definido en la configuracion de la BD.
define("DB_PASSWORD", "G95l9xv7dS");//Modificar por el password elegido
define("DB_DATABASE", "proyec34_recicladora");//Nombre de la base de datos reemplazar si se utilizo otro diferente al mencionado en el tutorial.
?>