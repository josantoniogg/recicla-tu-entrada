<?php
define('DB_USER', "proyec34"); // db user
define('DB_PASSWORD', "G95l9xv7dS"); // db password (mention your db password here)
define('DB_DATABASE', "proyec34_recicladora"); // database name
define('DB_SERVER', "localhost"); // db server
?>