<?php
  $name = "SERVER";
  if(!defined($name)){
    define("SERVER", "localhost");
    define("USER", "proyec34");
    define("PASSWORD", "G95l9xv7dS");
    define("DB", "proyec34_recicladora");
  }
?>